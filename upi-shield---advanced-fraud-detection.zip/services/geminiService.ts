
import { GoogleGenAI, Type } from "@google/genai";
import { Transaction, FraudAnalysisResult, DatasetStats } from "../types";

/**
 * Performs real-time behavioral protection for the BHIM ecosystem.
 * Utilizes the best performing regression model (ANN or Random Forest).
 */
export const analyzeTransaction = async (
  transaction: Transaction, 
  stats?: DatasetStats | null
): Promise<FraudAnalysisResult> => {
  // Fix: Always use new GoogleGenAI({apiKey: process.env.API_KEY}) directly
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const ecosystemContext = stats ? `
    BHIM ECOSYSTEM ANALYTICS:
    - Best Model Selected: ${stats.models.best}
    - ANN Training Accuracy: ${stats.models.ann.accuracy}%
    - Random Forest Accuracy: ${stats.models.randomForest.accuracy}%
    - Historical Mean Amount: ₹${stats.avgAmount}
    - Active Threat Vectors: ${stats.riskVectors.join(', ')}
  ` : "STANDALONE MODE: Heuristic scan active.";

  const prompt = `
    INCOMING TRANSACTION:
    Sender: ${transaction.sender_name} (${transaction.sender_upi})
    Receiver: ${transaction.receiver_name} (${transaction.receiver_upi})
    Amount: ₹${transaction.amount}
    Status: ${transaction.status}

    ${ecosystemContext}

    TASK: Act as the ${stats?.models.best || 'Unified Security'} engine. 
    Using the learned weights of the best performing model, analyze this transaction for fraud.
    Focus on amount anomalies, UPI ID reputation, and pattern deviations.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: prompt,
      config: {
        systemInstruction: `You are the BHIM Neural Protection Core. 
        Classify transactions using logic from ANN (Artificial Neural Network) or Random Forest models.
        Return output strictly in JSON format.`,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            riskScore: { type: Type.NUMBER, description: "Fraud probability (0-100)" },
            riskLevel: { type: Type.STRING, description: "Low, Medium, High, or Critical" },
            reasoning: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Inference points" },
            recommendation: { type: Type.STRING, description: "Protocol action" },
            activeModel: { type: Type.STRING, description: "Model name used for prediction" }
          },
          required: ["riskScore", "riskLevel", "reasoning", "recommendation", "activeModel"],
          propertyOrdering: ["riskScore", "riskLevel", "reasoning", "recommendation", "activeModel"]
        }
      }
    });

    // Fix: Use response.text property (not a method) as per guidelines
    const responseText = response.text || "{}";
    const parsed = JSON.parse(responseText);
    
    return {
      riskScore: parsed.riskScore ?? 0,
      riskLevel: parsed.riskLevel ?? 'Low',
      reasoning: parsed.reasoning ?? ["Pattern sync complete"],
      recommendation: parsed.recommendation ?? "Proceed with standard validation",
      activeModel: parsed.activeModel ?? (stats?.models.best || "Heuristic Engine")
    };
  } catch (error) {
    console.error("AI Analysis Failed:", error);
    return {
      riskScore: 0,
      riskLevel: 'Low',
      reasoning: ["Neural interface error"],
      recommendation: "Manual verification required"
    };
  }
};
