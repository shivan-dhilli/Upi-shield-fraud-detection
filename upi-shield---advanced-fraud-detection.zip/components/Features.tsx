
import React from 'react';

const features = [
  {
    title: "Real-time Detection",
    desc: "Transactions are analyzed within 200ms of initiation using our edge-compute inference engine.",
    icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>,
    color: "from-cyan-400 to-blue-500"
  },
  {
    title: "Pattern Recognition",
    desc: "Our ML models learn from millions of historic fraud cases to stay ahead of evolving phishing techniques.",
    icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 7v10c0 2.21 3.582 4 8 4s8-1.79 8-4V7M4 7c0 2.21 3.582 4 8 4s8-1.79 8-4M4 7c0-2.21 3.582-4 8-4s8 1.79 8 4" /></svg>,
    color: "from-purple-400 to-pink-500"
  },
  {
    title: "Device Fingerprinting",
    desc: "Verify hardware identity to prevent account takeovers and automated bot attacks on your wallets.",
    icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c0 3.517-1.009 6.799-2.753 9.571m-3.44-2.04l.054-.09a13.916 13.916 0 002.103-2.456M12 11c0-3.517 1.009-6.799 2.753-9.571m3.44 2.04l-.054.09a13.916 13.916 0 01-2.103 2.456M12 11V5l-8-4v8.177c1.135.251 2.226.65 3.232 1.164m6.135 8.659L12 21l-4-4.823M12 11a13.94 13.94 0 01-3.612 9.01M12 11a13.94 13.94 0 003.612 9.01" /></svg>,
    color: "from-emerald-400 to-teal-500"
  },
  {
    title: "Biometric Auth",
    desc: "Seamlessly integrate with device-native biometrics for frictionless, secure transaction approval.",
    icon: <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>,
    color: "from-orange-400 to-red-500"
  }
];

const Features: React.FC = () => {
  return (
    <section id="features" className="py-24 bg-slate-900/50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl font-bold font-space text-white">Advanced Protection Layers</h2>
          <p className="text-slate-400 max-w-2xl mx-auto">Our security stack combines traditional heuristics with modern deep learning to offer 360-degree transaction safety.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((f, i) => (
            <div key={i} className="group glass p-8 rounded-3xl border-white/5 hover:border-cyan-500/30 transition-all duration-500 hover:-translate-y-2">
              <div className={`w-12 h-12 rounded-2xl bg-gradient-to-br ${f.color} flex items-center justify-center text-white mb-6 shadow-lg transform group-hover:rotate-12 transition-transform`}>
                {f.icon}
              </div>
              <h3 className="text-xl font-bold text-white mb-4 font-space">{f.title}</h3>
              <p className="text-slate-400 text-sm leading-relaxed">{f.desc}</p>
              <div className="mt-6 pt-6 border-t border-white/5 flex items-center gap-2 text-cyan-400 text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
                Learn More 
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
