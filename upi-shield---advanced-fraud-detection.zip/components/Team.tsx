import React from 'react';

const team = [
  { 
    name: "M. Sampath Kumar", 
    role: "Frontend Architect", 
    // Direct link conversion for Google Drive image visibility
    img: "https://drive.google.com/uc?export=view&id=1kGh-XZ0Gon4vKAKzUxj9bIjOui0hBcd-" 
  },
  { 
    name: "B. Sai Eshwar", 
    role: "UI/UX Designer", 
    img: "https://raw.githubusercontent.com/StackBlitz/stackblitz-images/main/input_file_1.png" 
  },
  { 
    name: "K. Durga Sai", 
    role: "AI & ML Lead", 
    img: "https://raw.githubusercontent.com/StackBlitz/stackblitz-images/main/input_file_2.png" 
  },
  { 
    name: "S. Dhilliswari", 
    role: "AI & ML Lead", 
    img: "https://raw.githubusercontent.com/StackBlitz/stackblitz-images/main/input_file_3.png" 
  },
  { 
    name: "S. Yamini", 
    role: "Project Designer", 
    img: "https://raw.githubusercontent.com/StackBlitz/stackblitz-images/main/input_file_4.png" 
  },
];

const Team: React.FC = () => {
  return (
    <section id="team" className="py-24 relative overflow-hidden bg-[#020617]">
      {/* Subtle ambient background effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[600px] bg-cyan-500/5 blur-[120px] rounded-full pointer-events-none"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-20 space-y-4">
          <div className="inline-block px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-[10px] font-bold tracking-[0.3em] uppercase mb-4">
            Security Division
          </div>
          <h2 className="text-4xl md:text-6xl font-bold font-space text-white uppercase tracking-tighter">
            Team <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">Developers</span>
          </h2>
          <p className="text-slate-500 max-w-xl mx-auto text-sm md:text-base font-light">
            A cross-functional team dedicated to neutralizing UPI threats through advanced behavioral intelligence.
          </p>
        </div>

        {/* Improved layout for visibility with smaller images */}
        <div className="flex flex-wrap justify-center gap-10 md:gap-14">
          {team.map((member, i) => (
            <div key={i} className="group flex flex-col items-center text-center w-full sm:w-40 md:w-48">
              <div className="relative mb-6 w-32 h-32 md:w-40 md:h-40">
                {/* Visual Frame */}
                <div className="absolute inset-0 bg-gradient-to-br from-cyan-500/20 via-blue-500/20 to-purple-600/20 rounded-full border border-white/10 group-hover:scale-105 transition-transform duration-500 shadow-2xl"></div>
                
                {/* Image Container with Padding (p-6) to make images small and fit perfectly */}
                <div className="absolute inset-1 bg-slate-900 rounded-full overflow-hidden flex items-center justify-center p-6 border border-white/5">
                  <div className="w-full h-full rounded-full overflow-hidden relative bg-slate-800 flex items-center justify-center">
                    <img 
                      src={member.img} 
                      alt={member.name} 
                      className="w-full h-full object-contain transition-all duration-500 group-hover:scale-110"
                      loading="lazy"
                      onError={(e) => {
                        // Fallback if the Google Drive link has access issues
                        (e.target as HTMLImageElement).src = `https://ui-avatars.com/api/?name=${encodeURIComponent(member.name)}&background=0f172a&color=22d3ee&bold=true`;
                      }}
                    />
                    {/* Clear overlay for protection/visibility */}
                    <div className="absolute inset-0 bg-cyan-400/5 group-hover:opacity-0 transition-opacity"></div>
                  </div>
                </div>
                
                {/* High-tech scanning line */}
                <div className="absolute inset-0 z-20 rounded-full overflow-hidden pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="w-full h-0.5 bg-cyan-400 shadow-[0_0_10px_rgba(34,211,238,0.8)] absolute top-0 animate-[scan_2.5s_linear_infinite]"></div>
                </div>
              </div>
              
              <div className="space-y-1.5">
                <h3 className="text-base md:text-lg font-bold text-white font-space tracking-tight transition-colors group-hover:text-cyan-400">
                  {member.name}
                </h3>
                <div className="inline-block px-2.5 py-0.5 rounded border border-white/10 bg-white/5 group-hover:border-cyan-500/40 transition-all">
                  <p className="text-[9px] font-mono font-bold text-slate-400 uppercase tracking-widest group-hover:text-cyan-300">
                    {member.role}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes scan {
          0% { top: 0%; }
          100% { top: 100%; }
        }
      `}} />
    </section>
  );
};

export default Team;