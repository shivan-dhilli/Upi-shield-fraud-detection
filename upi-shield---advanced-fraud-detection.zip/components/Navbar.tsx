import React from 'react';

const Navbar: React.FC = () => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  // High-quality shield logo from input
  const logoUrl = "https://raw.githubusercontent.com/StackBlitz/stackblitz-images/main/input_file_5.png";

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4">
      <div className="max-w-7xl mx-auto flex items-center justify-between glass px-6 py-3 rounded-2xl border-white/5 bg-slate-950/40 backdrop-blur-xl">
        <div className="flex items-center gap-4 cursor-pointer group" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
          {/* Smaller, more focused container with zoom to fit the shield asset perfectly */}
          <div className="w-10 h-10 rounded-xl bg-black border border-white/10 flex items-center justify-center shadow-lg neon-glow-blue overflow-hidden transition-all group-hover:scale-105 group-hover:border-cyan-500/50">
            <img 
              src={logoUrl} 
              alt="UPI Shield Logo" 
              className="w-full h-full object-contain scale-[1.8] transition-transform duration-500"
              onError={(e) => {
                const target = e.target as HTMLImageElement;
                target.style.display = 'none';
                target.parentElement!.innerHTML = '<span class="text-xs font-bold text-cyan-400">U</span>';
              }}
            />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tighter text-white font-space leading-tight">UPI <span className="text-cyan-400">Shield</span></span>
            <span className="text-[8px] text-cyan-400/50 font-mono tracking-[0.2em] uppercase">Security Protocol</span>
          </div>
        </div>

        <div className="hidden md:flex items-center gap-8 text-xs font-bold uppercase tracking-widest text-slate-300">
          <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="hover:text-cyan-400 transition-colors">Home</button>
          <button onClick={() => scrollTo('footer')} className="hover:text-cyan-400 transition-colors">Contact</button>
        </div>

        <button 
          onClick={() => scrollTo('demo')}
          className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs uppercase transition-all transform hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(34,211,238,0.4)]"
        >
          Secure Now
        </button>
      </div>
    </nav>
  );
};

export default Navbar;