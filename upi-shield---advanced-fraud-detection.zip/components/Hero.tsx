import React from 'react';

const Hero: React.FC = () => {
  const scrollToDemo = () => {
    const el = document.getElementById('demo');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-[110vh] flex flex-col items-center justify-center overflow-hidden bg-[#020617]">
      {/* Background Ambient Glow */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full bg-[radial-gradient(circle_at_50%_50%,rgba(6,182,212,0.15)_0%,transparent_70%)]"></div>
      </div>
      
      {/* Spline Animation Layer (Background) */}
      <div className="absolute inset-0 z-0 flex items-center justify-center opacity-60">
        <div className="w-full h-full max-w-7xl transform scale-110 md:scale-125 lg:scale-150 transition-opacity duration-1000">
          <spline-viewer 
            url="https://prod.spline.design/eQHfH8eexYCr3uo4/scene.splinecode"
            className="w-full h-full"
            loading="lazy"
            hint="high-performance"
          ></spline-viewer>
        </div>
      </div>

      {/* Content Overlay Layer (Foreground) */}
      <div className="container mx-auto px-6 z-10 text-center pointer-events-none pt-20 pb-48">
        <div className="max-w-5xl mx-auto space-y-6">
          <div className="inline-block px-4 py-1.5 rounded-full border border-cyan-500/30 bg-slate-950/80 backdrop-blur-md text-cyan-400 text-[10px] font-bold tracking-[0.4em] uppercase pointer-events-auto transition-transform hover:scale-110 cursor-default">
            Dataset-Verified Security
          </div>
          
          <div className="space-y-8 group pointer-events-auto cursor-default">
            <h1 className="text-7xl md:text-[14rem] font-bold leading-none tracking-tighter text-white font-space drop-shadow-[0_0_60px_rgba(0,0,0,1)] transition-all duration-700 hover:scale-[1.08] hover:tracking-[-0.06em] select-none">
              UPI <br className="md:hidden" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-indigo-400 to-purple-600 transition-all duration-500 group-hover:drop-shadow-[0_0_40px_rgba(34,211,238,0.9)]">Shield</span>
            </h1>
            
            <p className="text-white font-mono text-lg md:text-3xl tracking-[0.5em] md:tracking-[0.8em] uppercase drop-shadow-[0_0_20px_rgba(0,0,0,0.8)] font-black transition-all duration-500 hover:tracking-[1em]">
              Detects fraud before you pay
            </p>
          </div>
          
          <div className="flex flex-col md:flex-row items-center gap-8 justify-center pt-12 pointer-events-auto">
            <button 
              onClick={scrollToDemo}
              className="px-14 py-6 bg-cyan-500 text-slate-950 font-black text-xs tracking-[0.2em] rounded-2xl uppercase hover:bg-cyan-300 transition-all shadow-[0_0_60px_rgba(34,211,238,0.5)] hover:scale-110 active:scale-95"
            >
              Train & Scan
            </button>
            <button className="text-white text-xs font-bold uppercase tracking-[0.2em] border-b-2 border-white/20 pb-2 hover:border-cyan-400 transition-all hover:text-cyan-400">
              Technical Documentation
            </button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator - Positioned even lower at bottom-8 to ensure clear separation */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 opacity-50 hover:opacity-100 transition-opacity cursor-pointer flex flex-col items-center gap-2 z-20 pointer-events-auto" onClick={scrollToDemo}>
        <span className="text-[10px] font-bold uppercase tracking-[0.4em] text-cyan-400">Deploy Scanner</span>
        <svg className="w-6 h-6 text-cyan-400 animate-bounce" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
        </svg>
      </div>
    </section>
  );
};

export default Hero;
