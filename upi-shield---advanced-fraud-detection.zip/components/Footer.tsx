import React from 'react';

const Footer: React.FC = () => {
  // High-quality shield logo from input
  const logoUrl = "https://raw.githubusercontent.com/StackBlitz/stackblitz-images/main/input_file_5.png";

  return (
    <footer id="footer" className="pt-24 pb-12 border-t border-white/5 relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-px bg-gradient-to-r from-transparent via-cyan-500/50 to-transparent"></div>
      
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2 space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-black border border-white/10 flex items-center justify-center shadow-lg overflow-hidden border-cyan-500/20">
                <img 
                  src={logoUrl} 
                  alt="UPI Shield Logo" 
                  className="w-full h-full object-contain scale-[1.8]"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.style.display = 'none';
                    target.parentElement!.innerHTML = '<span class="text-xs font-bold text-cyan-400">U</span>';
                  }}
                />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold tracking-tighter text-white font-space leading-none">UPI <span className="text-cyan-400">Shield</span></span>
                <span className="text-[9px] text-cyan-400/60 font-mono tracking-widest uppercase mt-1">Detects fraud before you pay</span>
              </div>
            </div>
            <p className="text-slate-400 max-w-md leading-relaxed">
              Securing every transaction, protecting every citizen. Built with passion for the future of Indian fintech.
            </p>
            <div className="flex gap-4">
               <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-400 transition-all border border-white/10">
                 <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.916 4.916 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.84 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg>
               </a>
               <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-cyan-500/20 text-slate-400 hover:text-cyan-400 transition-all border border-white/10">
                 <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.729.084-.729 1.205.084 1.838 1.236 1.838 1.236 1.07 1.835 2.809 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.135-.303-.54-1.523.105-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.399 3-.405 1.02.006 2.04.138 3 .405 2.28-1.552 3.285-1.23 3.285-1.23.645 1.653.24 2.873.12 3.176.765.84 1.23 1.91 1.23 3.22 0 4.61-2.805 5.625-5.475 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.825.57C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12"/></svg>
               </a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 font-space">Navigation</h4>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li><a href="#about" className="hover:text-cyan-400 transition-colors">Project Info</a></li>
              <li><a href="#features" className="hover:text-cyan-400 transition-colors">Tech Stack</a></li>
              <li><a href="#demo" className="hover:text-cyan-400 transition-colors">Simulations</a></li>
              <li><a href="#team" className="hover:text-cyan-400 transition-colors">Join Team</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6 font-space">Contact</h4>
            <ul className="space-y-4 text-slate-500 text-sm">
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-cyan-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                secure@upishield.io
              </li>
              <li className="flex items-center gap-2">
                <svg className="w-4 h-4 text-cyan-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                Bangalore, India
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-12 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6">
          <p className="text-slate-600 text-[10px] uppercase tracking-[0.2em]">
            © 2024 UPI Shield | Detects fraud before you pay
          </p>
          <div className="flex gap-8 text-slate-600 text-xs uppercase tracking-widest">
             <a href="#" className="hover:text-white transition-colors">Privacy Protocol</a>
             <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;