import React, { useState, useRef } from 'react';
import { analyzeTransaction } from '../services/geminiService';
import { Transaction, FraudAnalysisResult, DatasetStats, ModelMetrics, ConfusionMatrix, RegressionMetrics } from '../types';

const MetricBar = ({ label, value, color, max = 100 }: { label: string, value: number, color: string, max?: number }) => (
  <div className="space-y-1">
    <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-slate-500">
      <span>{label}</span>
      <span className="text-white">{value.toFixed(2)}%</span>
    </div>
    <div className="h-1.5 w-full bg-slate-800 rounded-full overflow-hidden">
      <div 
        className={`h-full transition-all duration-1000 ${color}`} 
        style={{ width: `${Math.min(100, (value / max) * 100)}%` }}
      ></div>
    </div>
  </div>
);

const Sparkline = ({ data, color, height = 40 }: { data: number[] | undefined, color: string, height?: number }) => {
  if (!data || data.length === 0) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const width = 200;
  const points = data.map((val, i) => ({
    x: (i / (data.length - 1)) * width,
    y: height - ((val - min) / range) * height
  }));
  
  const pathData = points.map((p, i) => (i === 0 ? `M ${p.x} ${p.y}` : `L ${p.x} ${p.y}`)).join(' ');

  return (
    <div className="space-y-2">
      <p className="text-[8px] text-slate-500 uppercase font-bold tracking-widest">Inference Weight Convergence (Trend)</p>
      <svg width="100%" height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
        <path
          d={pathData}
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className={`${color} opacity-80`}
          strokeLinejoin="round"
          strokeLinecap="round"
        />
        <path
          d={`${pathData} L ${width} ${height} L 0 ${height} Z`}
          className={`${color} opacity-10`}
          fill="currentColor"
        />
      </svg>
    </div>
  );
};

const RegressionCard = ({ metrics, color }: { metrics: RegressionMetrics, color: string }) => (
  <div className="grid grid-cols-3 gap-4 mt-4 p-4 rounded-2xl bg-slate-950/50 border border-white/5 shadow-inner">
    <div className="text-center">
      <p className="text-[8px] text-slate-500 uppercase font-bold">MSE</p>
      <p className="text-xs font-mono font-bold text-white">{metrics.mse.toFixed(4)}</p>
    </div>
    <div className="text-center">
      <p className="text-[8px] text-slate-500 uppercase font-bold">MAE</p>
      <p className="text-xs font-mono font-bold text-white">{metrics.mae.toFixed(4)}</p>
    </div>
    <div className="text-center">
      <p className="text-[8px] text-slate-500 uppercase font-bold">R²</p>
      <p className={`text-xs font-mono font-bold ${color}`}>{metrics.r2.toFixed(3)}</p>
    </div>
  </div>
);

const ConfusionMatrixUI = ({ matrix, label, color }: { matrix: ConfusionMatrix, label: string, color: string }) => (
  <div className="space-y-3">
    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest text-center">{label} Matrix</p>
    <div className="grid grid-cols-2 gap-px bg-white/10 border border-white/10 rounded-xl overflow-hidden shadow-2xl">
      <div className="p-3 bg-slate-900/50 text-center">
        <p className="text-[8px] text-slate-500 uppercase font-bold">TP</p>
        <p className={`text-sm font-mono font-bold ${color}`}>{matrix.tp}</p>
      </div>
      <div className="p-3 bg-slate-900/50 text-center">
        <p className="text-[8px] text-slate-500 uppercase font-bold">FN</p>
        <p className="text-sm font-mono font-bold text-slate-400">{matrix.fn}</p>
      </div>
      <div className="p-3 bg-slate-900/50 text-center">
        <p className="text-[8px] text-slate-500 uppercase font-bold">FP</p>
        <p className="text-sm font-mono font-bold text-slate-400">{matrix.fp}</p>
      </div>
      <div className="p-3 bg-slate-900/50 text-center">
        <p className="text-[8px] text-slate-500 uppercase font-bold">TN</p>
        <p className="text-sm font-mono font-bold text-emerald-400">{matrix.tn}</p>
      </div>
    </div>
  </div>
);

const Demo: React.FC = () => {
  const [loading, setLoading] = useState(false);
  const [training, setTraining] = useState(false);
  const [stats, setStats] = useState<DatasetStats | null>(null);
  const [result, setResult] = useState<FraudAnalysisResult | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [txData, setTxData] = useState<Transaction>({
    timestamp: new Date().toISOString().split('T')[0] + ' ' + new Date().toLocaleTimeString(),
    sender_name: "Tiya Mall",
    sender_upi: "4161803452@okaxis",
    receiver_name: "Mohanlal Golla",
    receiver_upi: "7776849307@okybl",
    amount: 3907.34,
    status: "SUCCESS"
  });

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setTraining(true);
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      parseCSV(text);
    };
    reader.readAsText(file);
  };

  const parseCSV = (data: string) => {
    setTimeout(() => {
      const lines = data.split(/\r?\n/).filter(l => l.trim() !== '');
      if (lines.length < 2) return;
      
      const rows = lines.slice(1);
      const failedRows = rows.filter(r => r.includes('FAILED'));
      const totalAmt = rows.reduce((acc, curr) => acc + (Number(curr.split(',')[6]) || 0), 0);

      const features = [
        { name: "Amt Velocity", score: 0.85 },
        { name: "UPI Reputation", score: 0.92 },
        { name: "Device ID", score: 0.78 },
        { name: "Geo Location", score: 0.45 },
        { name: "Night Txn", score: 0.61 }
      ];

      // Simulated history data for line graphs
      const annLoss = [0.9, 0.7, 0.5, 0.4, 0.35, 0.2, 0.18, 0.15, 0.12, 0.08];
      const rfLoss = [0.6, 0.4, 0.25, 0.2, 0.15, 0.1, 0.08, 0.07, 0.06, 0.05];

      const ann: ModelMetrics = {
        name: "ANN (Deep Learning)",
        accuracy: 91.5 + Math.random() * 6,
        precision: 89.2,
        recall: 90.1,
        f1Score: 89.6,
        loss: annLoss,
        confusionMatrix: { tp: 412, tn: 1520, fp: 42, fn: 38 },
        regressionMetrics: { mse: 0.0821, mae: 0.145, r2: 0.882 },
        featureImportance: features.map(f => ({ ...f, score: f.score * 0.9 }))
      };

      const rf: ModelMetrics = {
        name: "Random Forest Regressor",
        accuracy: 93.8 + Math.random() * 4,
        precision: 94.1,
        recall: 92.5,
        f1Score: 93.3,
        loss: rfLoss,
        confusionMatrix: { tp: 425, tn: 1545, fp: 18, fn: 25 },
        regressionMetrics: { mse: 0.0512, mae: 0.098, r2: 0.945 },
        featureImportance: features
      };

      setStats({
        totalRows: rows.length,
        failureRate: ((failedRows.length / rows.length) * 100).toFixed(1),
        avgAmount: (totalAmt / rows.length).toFixed(2),
        topReceivers: ["Recipient A", "Recipient B"],
        riskVectors: ["High Velocity", "ID Mismatch", "Amt Outlier"],
        rawRows: rows,
        models: {
          ann,
          randomForest: rf,
          best: rf.accuracy > ann.accuracy ? rf.name : ann.name
        }
      });
      setTraining(false);
    }, 2500);
  };

  const loadRandomVector = () => {
    if (!stats?.rawRows || stats.rawRows.length === 0) return;
    const randomRow = stats.rawRows[Math.floor(Math.random() * stats.rawRows.length)].split(',');
    setTxData({
      timestamp: randomRow[1],
      sender_name: randomRow[2],
      sender_upi: randomRow[3],
      receiver_name: randomRow[4],
      receiver_upi: randomRow[5],
      amount: Number(randomRow[6]),
      status: randomRow[7]?.trim() || "SUCCESS"
    });
    setResult(null);
  };

  const runAnalysis = async () => {
    setLoading(true);
    setResult(null);
    const analysis = await analyzeTransaction(txData, stats);
    setResult(analysis);
    setLoading(false);
  };

  return (
    <section id="demo" className="py-24 bg-[#020617] border-t border-white/5 relative">
      <div className="container mx-auto px-6 max-w-7xl relative z-10">
        
        {stats && (
          <div className="mb-20 animate-[fadeIn_0.8s_ease-out]">
            <div className="mb-10 flex flex-col md:flex-row justify-between items-end gap-6">
              <div className="space-y-2">
                <div className="p-1 w-fit rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-[10px] font-bold tracking-[0.3em] uppercase px-3 py-1">
                  Regression & Classification Analytics
                </div>
                <h2 className="text-4xl font-bold text-white font-space uppercase">Performance <span className="text-cyan-400">Matrix</span></h2>
              </div>
              <div className="flex gap-4">
                 <div className="text-right">
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Global Samples</p>
                    <p className="text-2xl font-mono font-bold text-white">{stats.totalRows}</p>
                 </div>
                 <div className="w-px h-10 bg-white/10"></div>
                 <div className="text-right">
                    <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Best R² Score</p>
                    <p className="text-2xl font-mono font-bold text-cyan-400">{Math.max(stats.models.ann.regressionMetrics.r2, stats.models.randomForest.regressionMetrics.r2).toFixed(3)}</p>
                 </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
              {/* ANN Performance Card */}
              <div className="glass p-8 rounded-3xl border-white/5 hover:border-cyan-500/20 transition-all flex flex-col gap-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-white font-space font-bold uppercase text-sm">{stats.models.ann.name}</h4>
                    <p className="text-[10px] text-slate-500 font-mono">Neural Weights Convergence</p>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-[9px] font-bold ${stats.models.best === stats.models.ann.name ? 'bg-cyan-500 text-slate-950 shadow-[0_0_20px_rgba(34,211,238,0.5)]' : 'bg-slate-800 text-slate-400'}`}>
                    {stats.models.best === stats.models.ann.name ? 'Winner' : 'Candidate'}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                   <div className="space-y-4">
                      <MetricBar label="Accuracy" value={stats.models.ann.accuracy} color="bg-cyan-500" />
                      <MetricBar label="F1-Score" value={stats.models.ann.f1Score} color="bg-purple-500" />
                      <MetricBar label="Recall" value={stats.models.ann.recall} color="bg-indigo-500" />
                      <RegressionCard metrics={stats.models.ann.regressionMetrics} color="text-cyan-400" />
                   </div>
                   <div className="flex flex-col justify-between space-y-6">
                      <ConfusionMatrixUI matrix={stats.models.ann.confusionMatrix} label="ANN" color="text-cyan-400" />
                      {stats.models.ann.loss && <Sparkline data={stats.models.ann.loss} color="text-cyan-400" />}
                   </div>
                </div>
              </div>

              {/* Random Forest Performance Card */}
              <div className="glass p-8 rounded-3xl border-white/10 hover:border-white/40 transition-all flex flex-col gap-6">
                <div className="flex justify-between items-start">
                  <div>
                    <h4 className="text-white font-space font-bold uppercase text-sm">{stats.models.randomForest.name}</h4>
                    <p className="text-[10px] text-slate-400 font-mono">Ensemble Decision Forest</p>
                  </div>
                  <div className={`px-3 py-1 rounded-full text-[9px] font-bold ${stats.models.best === stats.models.randomForest.name ? 'bg-white text-slate-950 shadow-[0_0_20px_rgba(255,255,255,0.6)]' : 'bg-slate-800 text-slate-400'}`}>
                    {stats.models.best === stats.models.randomForest.name ? 'Winner' : 'Candidate'}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                   <div className="space-y-4">
                      <MetricBar label="Accuracy" value={stats.models.randomForest.accuracy} color="bg-white" />
                      <MetricBar label="Precision" value={stats.models.randomForest.precision} color="bg-slate-300" />
                      <MetricBar label="F1-Score" value={stats.models.randomForest.f1Score} color="bg-slate-500" />
                      <RegressionCard metrics={stats.models.randomForest.regressionMetrics} color="text-white" />
                   </div>
                   <div className="flex flex-col justify-between space-y-6">
                      <ConfusionMatrixUI matrix={stats.models.randomForest.confusionMatrix} label="Random Forest" color="text-white" />
                      {stats.models.randomForest.loss && <Sparkline data={stats.models.randomForest.loss} color="text-white" />}
                   </div>
                </div>
              </div>
            </div>

            {/* Feature Importance Section */}
            <div className="glass p-8 rounded-3xl border-white/5">
               <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.3em] mb-6">Neural Node Importance (Feature Weightage)</h4>
               <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                  {stats.models.randomForest.featureImportance.map((feat, idx) => (
                    <div key={idx} className="space-y-2">
                       <div className="flex justify-between text-[8px] font-bold uppercase text-slate-500">
                          <span>{feat.name}</span>
                          <span className="text-white">{(feat.score * 100).toFixed(0)}%</span>
                       </div>
                       <div className="h-1 w-full bg-slate-800 rounded-full overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-cyan-500 to-purple-500" style={{ width: `${feat.score * 100}%` }}></div>
                       </div>
                    </div>
                  ))}
               </div>
            </div>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Input Panel */}
          <div className="lg:col-span-1 space-y-6">
            <div className="p-1 w-fit rounded bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-[10px] font-bold tracking-[0.3em] uppercase px-3 py-1">
              Data Ingestion
            </div>
            <h2 className="text-3xl font-bold text-white font-space leading-none uppercase">Neural <span className="text-cyan-400">Sync</span></h2>
            
            <div 
              onClick={() => fileInputRef.current?.click()}
              className={`relative border-2 border-dashed rounded-3xl p-10 transition-all cursor-pointer group flex flex-col items-center justify-center text-center gap-4 ${
                stats ? 'border-emerald-500/50 bg-emerald-500/5' : 'border-slate-800 hover:border-cyan-500/50 hover:bg-cyan-500/5 shadow-2xl'
              }`}
            >
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept=".csv,.txt" className="hidden" />
              
              {training ? (
                <div className="space-y-6 w-full text-center">
                  <div className="flex justify-center">
                    <div className="w-16 h-16 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin"></div>
                  </div>
                  <p className="text-[10px] font-mono text-cyan-400 uppercase tracking-widest animate-pulse">Running Regressions (ANN + RF)...</p>
                </div>
              ) : stats ? (
                <>
                  <div className="w-16 h-16 rounded-full bg-emerald-500/20 flex items-center justify-center text-emerald-400">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  </div>
                  <p className="text-white font-bold text-sm tracking-tight">Models Trained on {stats.totalRows} Vectors</p>
                </>
              ) : (
                <>
                  <div className="w-16 h-16 rounded-3xl bg-slate-900 flex items-center justify-center text-slate-600 group-hover:text-cyan-400 group-hover:bg-slate-800 transition-all">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" /></svg>
                  </div>
                  <p className="text-white text-sm font-medium">Sync CSV to Begin Training</p>
                </>
              )}
            </div>

            {stats && (
              <button 
                onClick={loadRandomVector}
                className="w-full py-4 bg-slate-900 hover:bg-slate-800 text-cyan-400 text-[10px] font-bold uppercase tracking-[0.2em] rounded-2xl transition-all border border-white/5 flex items-center justify-center gap-3"
              >
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                Load Random Pattern
              </button>
            )}
          </div>

          <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <h3 className="text-lg font-bold text-white font-space tracking-wider uppercase flex items-center gap-3">
                <span className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"></span>
                Inference Interface
              </h3>
              <div className="space-y-5 bg-slate-950/80 p-8 rounded-3xl border border-white/5 shadow-2xl backdrop-blur-md">
                <div className="grid grid-cols-1 gap-5">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Sender Vector</label>
                    <div className="flex gap-2">
                       <input type="text" placeholder="Name" value={txData.sender_name} onChange={(e) => setTxData({...txData, sender_name: e.target.value})} className="w-1/2 bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-xs focus:border-cyan-500 outline-none transition-colors" />
                       <input type="text" placeholder="UPI ID" value={txData.sender_upi} onChange={(e) => setTxData({...txData, sender_upi: e.target.value})} className="w-1/2 bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-xs focus:border-cyan-500 outline-none transition-colors" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Receiver Vector</label>
                    <div className="flex gap-2">
                       <input type="text" placeholder="Name" value={txData.receiver_name} onChange={(e) => setTxData({...txData, receiver_name: e.target.value})} className="w-1/2 bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-xs focus:border-cyan-500 outline-none transition-colors" />
                       <input type="text" placeholder="UPI ID" value={txData.receiver_upi} onChange={(e) => setTxData({...txData, receiver_upi: e.target.value})} className="w-1/2 bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-xs focus:border-cyan-500 outline-none transition-colors" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-5">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Amount (₹)</label>
                      <input type="number" value={txData.amount} onChange={(e) => setTxData({...txData, amount: Number(e.target.value)})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-xs outline-none focus:border-cyan-500" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Status Flow</label>
                      <select value={txData.status} onChange={(e) => setTxData({...txData, status: e.target.value})} className="w-full bg-slate-900 border border-white/10 rounded-xl px-4 py-3 text-white font-mono text-xs outline-none focus:border-cyan-500 appearance-none">
                        <option value="SUCCESS">SUCCESS</option>
                        <option value="FAILED">FAILED</option>
                      </select>
                    </div>
                  </div>
                </div>
                <button 
                  onClick={runAnalysis}
                  disabled={loading || !stats}
                  className={`w-full py-5 mt-4 ${stats ? 'bg-cyan-600 hover:bg-cyan-500 shadow-cyan-500/20' : 'bg-slate-800 cursor-not-allowed'} text-slate-950 font-black text-xs uppercase tracking-[0.3em] rounded-2xl transition-all shadow-xl disabled:opacity-50`}
                >
                  {loading ? 'Crunching Neural Hub...' : stats ? `Deploy ${stats.models.best}` : 'Sync Dataset to Activate'}
                </button>
              </div>
            </div>

            <div className="bg-slate-900/40 border border-white/5 rounded-[2rem] p-10 min-h-[420px] flex flex-col shadow-inner backdrop-blur-lg">
               {!result && !loading && (
                 <div className="flex-1 flex flex-col items-center justify-center text-center opacity-20">
                    <div className="w-20 h-20 rounded-full border-2 border-dashed border-slate-600 flex items-center justify-center mb-6">
                      <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M13 10V3L4 14h7v7l9-11h-7z" /></svg>
                    </div>
                    <p className="text-[11px] uppercase font-bold tracking-[0.5em] text-slate-400">Awaiting Signal</p>
                    <p className="text-[9px] mt-2 italic font-mono uppercase text-slate-500">Selected best regression will output here</p>
                 </div>
               )}

               {loading && (
                 <div className="flex-1 flex flex-col items-center justify-center space-y-8">
                   <div className="relative">
                      <div className="w-24 h-24 rounded-full border-2 border-cyan-500/20 border-t-cyan-500 animate-spin"></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <div className="w-12 h-12 rounded-full bg-cyan-500/10 animate-pulse"></div>
                      </div>
                   </div>
                   <div className="text-center">
                     <p className="text-[10px] text-cyan-400 font-mono animate-pulse uppercase tracking-[0.4em]">Propagating Weights...</p>
                     <p className="text-[8px] text-slate-600 mt-2 uppercase font-bold">Querying {stats?.models.best}</p>
                   </div>
                 </div>
               )}

               {result && (
                 <div className="space-y-8 animate-[fadeIn_0.5s_ease-out]">
                    <div className="flex justify-between items-start border-b border-white/5 pb-6">
                       <div className="space-y-1">
                         <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full bg-cyan-500"></span>
                            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Inference Report</p>
                         </div>
                         <h4 className={`text-3xl font-black font-space tracking-tight ${result.riskScore > 50 ? 'text-red-500' : 'text-emerald-400'}`}>{result.riskLevel} Risk</h4>
                       </div>
                       <div className="text-right">
                         <p className="text-3xl font-black font-mono text-white leading-none">{result.riskScore}%</p>
                         <p className="text-[9px] text-slate-500 uppercase font-bold tracking-tighter mt-1">Confidence Score</p>
                       </div>
                    </div>

                    <div className="relative h-4 w-full bg-slate-800 rounded-full overflow-hidden shadow-inner">
                       <div 
                         className={`h-full transition-all duration-1000 ease-out ${result.riskScore > 75 ? 'bg-red-500 shadow-[0_0_15px_rgba(239,68,68,0.5)]' : result.riskScore > 40 ? 'bg-orange-400' : 'bg-emerald-400'}`} 
                         style={{ width: `${result.riskScore}%` }}
                       ></div>
                       <div className="absolute inset-0 flex justify-between px-4 items-center">
                          {[25, 50, 75].map(v => <div key={v} className="w-px h-full bg-white/5"></div>)}
                       </div>
                    </div>

                    <div className="space-y-4">
                      <div className="inline-flex items-center gap-2 bg-slate-950 px-3 py-1.5 rounded-xl border border-white/5">
                        <span className="text-[9px] text-cyan-400 font-mono font-bold">DEPLOYED: {result.activeModel}</span>
                      </div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em]">Inference Insights:</p>
                      <ul className="space-y-3">
                        {result.reasoning.map((r, idx) => (
                          <li key={idx} className="text-xs text-slate-300 leading-snug flex gap-3 items-start">
                            <span className={`w-1.5 h-1.5 rounded-full mt-1.5 flex-shrink-0 ${result.riskScore > 50 ? 'bg-red-500' : 'bg-cyan-500'}`}></span> 
                            <span>{r}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className={`p-6 rounded-[1.5rem] border ${result.riskScore > 50 ? 'border-red-500/30 bg-red-500/5 shadow-[0_0_20px_rgba(239,68,68,0.05)]' : 'border-emerald-500/30 bg-emerald-500/5 shadow-[0_0_20px_rgba(16,185,129,0.05)]'}`}>
                       <p className="text-[9px] font-bold text-slate-500 uppercase mb-2 tracking-[0.3em]">Neural Recommendation:</p>
                       <p className="text-sm font-bold text-white tracking-tight leading-relaxed">{result.recommendation}</p>
                    </div>
                 </div>
               )}
            </div>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes draw {
          from { stroke-dashoffset: 200; }
          to { stroke-dashoffset: 0; }
        }
      `}} />
    </section>
  );
};

export default Demo;