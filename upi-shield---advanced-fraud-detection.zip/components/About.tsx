
import React from 'react';

const About: React.FC = () => {
  return (
    <section id="about" className="py-24 relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="aspect-video rounded-3xl overflow-hidden glass border-white/10 shadow-2xl">
              <img src="https://picsum.photos/seed/cybersecurity/800/450" alt="Cyber Security Visual" className="w-full h-full object-cover opacity-60 mix-blend-overlay" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-20 h-20 rounded-full bg-cyan-500/20 flex items-center justify-center border border-cyan-400/30 animate-pulse">
                   <svg className="w-10 h-10 text-cyan-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                   </svg>
                </div>
              </div>
            </div>
            {/* Stats */}
            <div className="absolute -bottom-6 -right-6 glass p-6 rounded-2xl border-white/10 hidden md:block">
              <p className="text-3xl font-bold text-cyan-400 font-space">99.9%</p>
              <p className="text-xs text-slate-400 uppercase tracking-wider">Detection Accuracy</p>
            </div>
          </div>

          <div className="space-y-6">
            <h2 className="text-4xl font-bold text-white font-space leading-tight">
              Combating the Rising Tide of <br />
              <span className="text-cyan-400">Digital Financial Fraud</span>
            </h2>
            <p className="text-slate-400 leading-relaxed text-lg font-light">
              UPI Shield is a unified fraud detection protocol designed to secure the Bharat Interface for Money (BHIM) and the UPI ecosystem. We use advanced behavioral biometrics and transaction pattern analysis to identify scams in milliseconds.
            </p>
            <div className="space-y-4">
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center mt-1">
                  <div className="w-2 h-2 rounded-full bg-cyan-400"></div>
                </div>
                <div>
                  <h4 className="text-white font-bold">Heuristic Analysis</h4>
                  <p className="text-slate-500 text-sm">Identifying unusual transaction bursts and abnormal value distributions.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-500/20 flex items-center justify-center mt-1">
                  <div className="w-2 h-2 rounded-full bg-purple-400"></div>
                </div>
                <div>
                  <h4 className="text-white font-bold">Social Graph Monitoring</h4>
                  <p className="text-slate-500 text-sm">Mapping sender-receiver relationships to flag suspicious money laundering chains.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;